module.exports = {
  preset: 'ts-jest/presets/js-with-ts',
  testEnvironment: 'jsdom',
  verbose: true,
  transformIgnorePatterns: ["node_modules/(?!@tmtsoftware/esw-ts|uuid)"]
}
