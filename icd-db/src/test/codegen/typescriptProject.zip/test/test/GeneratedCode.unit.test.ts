import {Test} from "../src/Test";

describe('Test generated code', () => {
    test('test', () => {
        expect(Test.subsystem).toEqual('TEST')
        expect(Test.Env_ctrl.prefix.componentName).toEqual('env.ctrl')
    })
})

