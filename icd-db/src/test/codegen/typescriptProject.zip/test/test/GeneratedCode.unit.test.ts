import {Test} from "../src/Test";
import {booleanKey, EventKey, EventName, intKey, Prefix, stringKey} from "@tmtsoftware/esw-ts";

describe('Test generated code', () => {

    test('test', () => {
        expect(Test.subsystem).toEqual('TEST')

        expect(Test.Rtc.prefix == new Prefix('CSW', "rtc"))
        expect(Test.Rtc.CONFIGURECommand.commandName == "CONFIGURE")
        expect(Test.Rtc.CONFIGURECommand.wfsEnabledKey == booleanKey('wfsEnabled'))

        expect(Test.Env_ctrl.prefix == new Prefix('CSW', "env.ctrl"))
        expect(Test.Env_ctrl.HeartbeatEvent.eventKey == new EventKey(new Prefix('CSW', 'env.ctrl'), new EventName('heartbeat')))
        expect(Test.Env_ctrl.HeartbeatEvent.heartbeatKey == intKey('heartbeat'))
        expect(Test.Env_ctrl.AdminCommandCommand.commandName == "adminCommand")

        expect(Test.LgsWfs.LGS_WFS_INITIALIZECommand.commandName == "LGS_WFS_INITIALIZE")
        expect(Test.LgsWfs.LGS_WFS_INITIALIZECommand.modeCommandTestKey == booleanKey('modeCommandTest'))
        expect(Test.LgsWfs.LGS_WFS_INITIALIZECommand.wfsUsedKey == stringKey('wfsUsed'))
    })
})

