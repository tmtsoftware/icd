package example;

import csw.params.commands.CommandName;
import csw.params.events.EventKey;
import csw.params.events.EventName;
import csw.params.javadsl.JKeyType;
import csw.prefix.javadsl.JSubsystem;
import csw.prefix.models.Prefix;
import org.junit.Test;

@SuppressWarnings("ConstantValue")
public class TestSpec {

    @Test
    public void basicTests() {
        assert (test.Test.subsystem.equals("TEST"));
        // Note: CSW is used here since there is no official CSW subsystem named TEST
        assert (test.Test.Rtc.prefix.equals(new Prefix(JSubsystem.CSW, "rtc")));
        assert (test.Test.Rtc.CONFIGURECommand.commandName.equals(new CommandName("CONFIGURE")));
        assert (test.Test.Rtc.CONFIGURECommand.wfsEnabledKey.equals(JKeyType.BooleanKey().make("wfsEnabled")));

        assert (test.Test.Env_ctrl.prefix.equals(new Prefix(JSubsystem.CSW, "env.ctrl")));
        assert (test.Test.Env_ctrl.HeartbeatEvent.eventKey.equals(new EventKey(new Prefix(JSubsystem.CSW, "env.ctrl"), new EventName("heartbeat"))));
        assert (test.Test.Env_ctrl.HeartbeatEvent.heartbeatKey.equals(JKeyType.IntKey().make("heartbeat")));
        assert (test.Test.Env_ctrl.AdminCommandCommand.commandName.equals(new CommandName("adminCommand")));

        assert (test.Test.LgsWfs.LGS_WFS_INITIALIZECommand.commandName.equals(new CommandName("LGS_WFS_INITIALIZE")));
        assert (test.Test.LgsWfs.LGS_WFS_INITIALIZECommand.modeCommandTestKey.equals(JKeyType.BooleanKey().make("modeCommandTest")));
        assert (test.Test.LgsWfs.LGS_WFS_INITIALIZECommand.wfsUsedKey.equals(JKeyType.StringKey().make("wfsUsed")));
    }
}
