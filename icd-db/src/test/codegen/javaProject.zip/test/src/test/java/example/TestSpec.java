package example;

import org.junit.Test;

public class TestSpec {

    @Test
    public void should_have_correct_subsystem() {
	assert(test.Test.subsystem.equals("TEST"));
    }
}
