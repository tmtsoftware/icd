import sbt._

object Csw {
  private val Org = "com.github.tmtsoftware.csw"
  private val Version = "5.0.1"
  val `csw-params`          = Org %% "csw-params" % Version
}

object Dependencies {
  val `junit4-interface`       = "com.github.sbt"           % "junit-interface"        % "0.13.3"
}
