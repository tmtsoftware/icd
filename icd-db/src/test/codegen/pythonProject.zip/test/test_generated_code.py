from Test import Test
from csw.ParameterSetType import *
from csw.Prefix import Prefix
from csw.Parameter import *
from csw.Event import EventName
from csw.EventKey import EventKey
from csw.Subsystem import Subsystem

def test_generated_code():
    assert Test.subsystem == "TEST"

    # Note: CSW is used here since there is no official CSW subsystem named TEST
    assert Test.Rtc.prefix == Prefix(Subsystem.CSW, "rtc")
    assert Test.Rtc.CONFIGURECommand.commandName == "CONFIGURE"
    assert Test.Rtc.CONFIGURECommand.wfsEnabledKey == BooleanKey.make("wfsEnabled")

    assert Test.Env_ctrl.prefix == Prefix(Subsystem.CSW, "env.ctrl")
    assert Test.Env_ctrl.HeartbeatEvent.eventKey == EventKey(Prefix(Subsystem.CSW, "env.ctrl"), EventName("heartbeat"))
    assert Test.Env_ctrl.HeartbeatEvent.heartbeatKey == IntKey.make("heartbeat")
    assert Test.Env_ctrl.AdminCommandCommand.commandName == "adminCommand"

    assert Test.LgsWfs.LGS_WFS_INITIALIZECommand.commandName == "LGS_WFS_INITIALIZE"
    assert Test.LgsWfs.LGS_WFS_INITIALIZECommand.modeCommandTestKey == BooleanKey.make("modeCommandTest")
    assert Test.LgsWfs.LGS_WFS_INITIALIZECommand.wfsUsedKey == StringKey.make("wfsUsed")
