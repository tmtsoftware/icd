from Test import Test

def test_generated_code():
    assert Test.subsystem == "TEST"
    assert Test.Env_ctrl.prefix.componentName == "env.ctrl"

