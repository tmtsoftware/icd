import sbt._

object Csw {
  private val Org = "com.github.tmtsoftware.csw"
  private val Version = "6.0.0"
  val `csw-params`          = Org %% "csw-params" % Version
}

object Dependencies {
  lazy val scalaTest = "org.scalatest" %% "scalatest" % "3.2.19"
}
