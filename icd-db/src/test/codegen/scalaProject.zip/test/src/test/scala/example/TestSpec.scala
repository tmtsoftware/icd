package example

import org.scalatest.funsuite.AnyFunSuite
import test.Test

class TestSpec extends AnyFunSuite {
  test("Basic test") {
    assert(Test.subsystem == "TEST")
  }
}
