package example

import csw.params.commands.CommandName
import csw.params.core.generics.KeyType.{BooleanKey, IntKey, StringKey}
import csw.params.events.{EventKey, EventName}
import csw.prefix.models.{Prefix, Subsystem}
import org.scalatest.funsuite.AnyFunSuite
import test.Test

class TestSpec extends AnyFunSuite {
  test("Basic test") {
    assert(Test.subsystem == "TEST")

    // Note: CSW is used here since there is no official CSW subsystem named TEST
    assert(Test.Rtc.prefix == Prefix(Subsystem.CSW, "rtc"))
    assert(Test.Rtc.CONFIGURECommand.commandName == CommandName("CONFIGURE"))
    assert(Test.Rtc.CONFIGURECommand.wfsEnabledKey == BooleanKey.make("wfsEnabled"))

    assert(Test.`Env.ctrl`.prefix == Prefix(Subsystem.CSW, "env.ctrl"))
    assert(Test.`Env.ctrl`.HeartbeatEvent.eventKey == EventKey(Prefix(Subsystem.CSW, "env.ctrl"), EventName("heartbeat")))
    assert(Test.`Env.ctrl`.HeartbeatEvent.heartbeatKey == IntKey.make("heartbeat"))
    assert(Test.`Env.ctrl`.AdminCommandCommand.commandName == CommandName("adminCommand"))

    assert(Test.LgsWfs.LGS_WFS_INITIALIZECommand.commandName == CommandName("LGS_WFS_INITIALIZE"))
    assert(Test.LgsWfs.LGS_WFS_INITIALIZECommand.modeCommandTestKey == BooleanKey.make("modeCommandTest"))
    assert(Test.LgsWfs.LGS_WFS_INITIALIZECommand.wfsUsedKey == StringKey.make("wfsUsed"))
  }
}
